1. PaCRISPR_Independent_Positive_26.fasta: 26 newly discovered, highly distinct anti-CRISPRs collected as positive samples for the independent dataset from emerging papers that were recorded in the unified online anti-CRISPR resource (https://docs.google.com/spreadsheets/d/17BR_Cy2jmokSKVZQwq7U6QgMUCUM5OBjnVnWbmsc6Eg/edit#gid=1470008611).

2. PaCRISPR_Independent_Negative_260.fasta: 260 non-anti-CRISPRs as negative samples for the independent dataset using the similar criteria to the selection of negative samples in the training dataset. They have less than 40% sequence similarity against the training dataset and the positive samples in the independent dataset.

3. PaCRISPR_Independent_Negative_Phage_Long_266.fasta: 266 non-anti-CRRISPRs from phages. They have less than 40% sequence similarity against each other and the training and independent datasets, and contain only sequences with length more than 350 residues.

4. PaCRISPR_Independent_Negative_MGE_Long_597.fasta: 597 non-anti-CRRISPRs from bacterial known and putative MGEs. They have less than 40% sequence similarity against each other and the training and independent datasets, and contain only sequences with length no less than 350 residues.


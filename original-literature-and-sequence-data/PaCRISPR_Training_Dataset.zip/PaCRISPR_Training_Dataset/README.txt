1. PaCRISPR_Training_Positive_Original_488.fasta: 488 experimentally validated anti-CRISPRs from existing databases and from the literature.

2. PaCRISPR_Training_Positive_98.fasta: 98 sequences for the positive samples in the training dataset, after removing redundant sequences with more than 70% sequence identity. 

3. PaCRISPR_Training_Negative_902.fasta: 902 sequences for negative samples in the training dataset isolated from phages or from bacterial MGEs (which may be known or putative MGEs), where the given bacterial genera are known to harbour anti-CRISPRs. They have less than 40% sequence similarity to each other and the 98 positive samples. Their lengths fall in the range between 50 and 350 residues, which is similar in length to the 98 positive samples.